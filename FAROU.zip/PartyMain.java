import Models.*;

import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList;


public class PartyMain {
	static ArrayList<Animals> animalsList= new ArrayList<Animals>();
	static ArrayList<String> musicList = new ArrayList<String>();
	static ArrayList<String> playedList= new ArrayList<String>();

	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		fullMusicList();
		
		String userCommand;
		System.out.println("Welcome to the lion king party");
		System.out.println("-------------------------------------------------");
		System.out.println();
		
		System.out.println("Mufasa may:");
		System.out.println("Add a new guest (Name, specie name, song)");
		System.out.println("Remove a guest");
		System.out.println("-------------------------------------------------");
		
		System.out.println();
		System.out.println("Rafiki may:");
		System.out.println("Check if a guest is allowed by its name");
		System.out.println("Check which are the needs by animal name");
		System.out.println("-------------------------------------------------");
		
		System.out.println();
		System.out.println("Zazu may:");
		System.out.println("Pick a random song");
		System.out.println("Check which songs were already played");
		
		System.out.println("-------------------------------------------------");
		System.out.println();
		System.out.println();
		do{
			System.out.println();
			System.out.println();
			
			System.out.println("Spicify your needs with the following keywords");
			System.out.println();
			System.out.println();
			System.out.println("Say 'Exit', 'Add_guest', 'Remove_guest', 'Check_guest', 'Check_needs', 'Pick_song' or 'Check_p_song' ");
			userCommand = scanner.next();

			switch(userCommand){
				case "Add_guest":
					addGuest();
					break;
					
				case "Remove_guest":
					System.out.println("Say the name of the Guest that you wants to remove");
					String name = scanner.next();
					removeGuest(name);
					
					break;
					
				case "Check_guest":
					System.out.println("Name of the Guest that you wants to check : ");
					String nameToCheck = scanner.next();
					checkGuest(nameToCheck);
					
					break;
					
                case "Check_needs":
                	String needBy;
                	boolean outLoop=false;
        			do{
        			System.out.println("List animal needs by animal or specie name");
        			System.out.println("Write 'animal' or 'specie'");
        			 needBy = scanner.next();
        			 if((needBy.equalsIgnoreCase("animal"))){
        				 listById("animal");
        				 outLoop=true;
        			 }else if((needBy.equalsIgnoreCase("specie"))){
        				 listById("specie");
        				 outLoop=true;
        			 }else{
        				 outLoop=false;	 
        			 }
        				 
        			 
        			}while(!outLoop);
					break;
					
                case "Pick_song":
                	pickSong();
					break;
                case "Check_p_song":
                	checkPlayedSong();
					break;

			}
			
		}while(!userCommand.equals("Exit"));

		
	}
	
	
	
	
	
	
	
	public static void listById(String id) {
		if(animalsList.size()==0){
			System.out.println("The guest list is empty !");
		}else{
			switch(id){
			case "animal": 
				for(int i=0;i<animalsList.size();i++) {
				       System.out.println(animalsList.get(i).getName()+" | "+animalsList.get(i).animalNeeds());
				    }
				break;
			case "specie":	
				for(int i=0;i<animalsList.size();i++) {
				       System.out.println("The "+animalsList.get(i).getSpecieName()+" | "+animalsList.get(i).animalNeeds());
				    }
				break;
			}
		}
		
				
	}


	public static void fullMusicList(){
		musicList.add("Clean Bandit - Symphony feat. Zara Larsson");
		musicList.add("Aura - If You ");
		musicList.add("Cardinale - Forever Young");
		musicList.add("Delia Rus - Tatuaj pe inima");
		musicList.add("Armin van Buuren & Garibay - I Need You");
		musicList.add("Carla's Dreams - Beretta");
		
		
	}

	public static void addGuest(){
	    int counter=0;
		String name = null;
		if(animalsList.size()>0){
			boolean validName = false;

			do{
				counter=0;
				System.out.println("Say the name of the Guest");
				 name = scanner.next();
					for(int i=0;i<animalsList.size();i++) {
				    if((animalsList.get(i).getName().equalsIgnoreCase(name))) {
				    	counter++;		
				    	System.out.println(counter);
				    }
				   
				}
					if(counter==0){	validName=true;}
					else{validName=false;}

			}while(!validName);
		}else{
			System.out.println("Say the name of the Guest");
			 name = scanner.next();
			
		}
		
			
		System.out.println("Say the name of its Spicie");
		String spicie = scanner.next();
		
		System.out.println("The recommended song for the party is: ");
		String song = scanner.next();
		
		boolean checkAnimalType=false;
		Animals animal;
		
		while(!checkAnimalType){
			System.out.println("The guest is a (Flying/Landing/Swimming)animal: ");
			String s = scanner.next();
		switch(s){
		case "Flying":
			animal= new FlyingAnimals(name,spicie,song);
			animalsList.add(animal);
			checkAnimalType=true;
			break;
			
		case "Landing":
			boolean outL=false;
			int nbPows;
			do{
			System.out.println("How many pows the animal have ? ");
			nbPows = scanner.nextInt();
			if(nbPows>0){
				 outL=true;
			 }else{
				 outL=false;
			 }
			}while(!outL);
			animal= new LandAnimals(name,spicie,song,nbPows);
			animalsList.add(animal);
			checkAnimalType=true;
			break;
			
		case "Swimming":
			String swimArea;
			boolean outLoop=false;
			do{
			System.out.println("Swimming From the sea/river");
			 swimArea = scanner.next();
			 if((swimArea.equalsIgnoreCase("sea"))||(swimArea.equalsIgnoreCase("river"))){
				 outLoop=true;
			 }else{
				 outLoop=false;
			 }
			}while(!outLoop);
			animal= new SwimingAnimals(name,spicie,song,swimArea);
			animalsList.add(animal);
			checkAnimalType=true;
			break;
			
		default: checkAnimalType=false;
	
	}
		
	}
		System.out.println("There is : "+animalsList.size()+" registred guest");
			
	}
	
	public static void removeGuest(String name){
		boolean p=false;
		for(int i=0;i<animalsList.size();i++) {
	        if(animalsList.get(i).getName().equals(name)) {
	            animalsList.remove(i);
	            p=true;
	        }
	    }
		if(p &&(animalsList.size()>0) ){
			System.out.println("There is : "+animalsList.size()+" left ib the guest list");
		}else if(animalsList.size()==0){
			System.out.println("The list is empty");
		}else{
			System.out.println("The animal that you wants to remove is already removed or doesn't exist !");	
		}
		
	}
	
	public static void pickSong(){
		try {
			String random = musicList.get(new Random().nextInt(musicList.size()));
			playedList.add(random);
			System.out.println("There is : "+playedList.size()+" music in the played list");
			for(int i=0;i<musicList.size();i++) {
		        if(musicList.get(i).equals(random)) {
		        	musicList.remove(i);
		        	System.out.println("There is : "+musicList.size()+" left in music list");
		        }
		    }
		} catch (Exception e) {
			System.out.println("music list is empty");
		}
		
		
	}
	public static void checkPlayedSong(){
		
		if(playedList.size()==0){
			System.out.println("There is no played songs yet !");	
		}
		else{
			System.out.println("List of played music:");
			for(int i=0;i<playedList.size();i++) {
				switch(i){
				case 0:
					System.out.println("the " + (i+1) + " st one is: "+ playedList.get(i));
					break;
				case 1:
					System.out.println("the " + (i+1) + " nd one is: "+ playedList.get(i));
					break;
				case 2:
					System.out.println("the " + (i+1) + " rd one is: "+ playedList.get(i));
					break;
				default:
					System.out.println("the " + (i+1) + " th one is: "+ playedList.get(i));
					
				}
					       
		    }
		}
		
	}
	public static void checkGuest(String name){
	if(animalsList.size()==0){
		System.out.println("The guest list is empty !");
	}else{
		for(int i=0;i<animalsList.size();i++) {
	        if((animalsList.get(i).getName().equals(name))||(animalsList.get(i).getSpecieName().equals(name))) {
	           System.out.println(name+" is on the guest list"); 
	        }else{
	           System.out.println(name+" is not in the guest list");
	        }
	    }	
	}
					
	}
	
	}



