package Models;

public abstract class Animals implements AnimalNeeds{
	private String name;
	private String specie_name;
	private String song;


	public Animals(String name, String specie_name, String song){
		super();
		this.name=name;
		this.specie_name=specie_name;
		this.song=song;
	}

public Animals() {
		// TODO Auto-generated constructor stub
	}

	// Getters and Setters
	public void setName(String name){
		this.name=name;

	}

	public void setSpecieName(String specie_name){
        this.specie_name=specie_name;
	}

	public void setSong(String song){
		this.song=song;

	}


	public String getName(){
		return this.name;
	}

	public String getSpecieName(){
		return this.specie_name;
	}

	public String getSong(){
		return this.song;
	}


	public abstract  String animalNeeds();

}
