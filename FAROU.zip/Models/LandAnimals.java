package Models;

public class LandAnimals extends Animals{
	
	private int nbPow;

	public LandAnimals(){
		super();
		this.nbPow=0;
		
	}

	public LandAnimals(String name, String specie_name, String song, int nbPow){
		super(name,specie_name,song);
		this.nbPow=nbPow;
	}

	public String animalNeeds(){
		return " is a Landing animal with "+this.getNbPows()+ " pows, he needs to land to the Main entrance";
	}

	

	public int getNbPows() {return this.nbPow;}
	public void setNbPows(int nbPow){this.nbPow=nbPow;}
	


}
