package Models;

public interface AnimalNeeds {
	public String animalNeeds();
	
}
