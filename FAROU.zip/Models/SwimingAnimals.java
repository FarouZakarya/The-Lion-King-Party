package Models;

public class SwimingAnimals extends Animals{
	private String comingPlace;
	public SwimingAnimals(){
		super();
	}

	public SwimingAnimals(String name, String specie_name, String song, String comingPlace){
		super(name,specie_name,song);
		this.comingPlace=comingPlace;
	}

	public String animalNeeds(){
		return " is a Swiming animal he came from "+this.getComingPlace()+" and he needs to swim";
	}

	public String getComingPlace() {
		return comingPlace;
	}

	public void setComingPlace(String comingPlace) {
		this.comingPlace = comingPlace;
	}


	
}
