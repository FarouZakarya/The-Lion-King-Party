package Models;

public class FlyingAnimals extends Animals{

	public FlyingAnimals(){
		super();
	}

	public FlyingAnimals(String name, String specie_name, String song){
		super(name,specie_name,song);
	}

	public String animalNeeds(){
		return " is a Flying animal and he needs the extension of its wings";
	}

	
	
}
